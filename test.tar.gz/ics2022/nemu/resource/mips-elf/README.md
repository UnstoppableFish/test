This is a dummy ELF file used by qemu-system-mips32 to start.
